﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Vehicles_Showroom : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Tanmay\Documents\vehicel.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        public Vehicles_Showroom()
        {
            InitializeComponent();
        }

        private void Vehicles_Showroom_Load(object sender, EventArgs e)
        {
            this.ActiveControl = textBox1;
            textBox1.Focus();
            Display();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Clear();
            textBox3.Text = " ";
            textBox4.Clear();
            textBox5.Text = " ";
            textBox6.Clear();
            textBox7.Text = " ";
            textBox8.Clear();
            textBox1.Focus();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"INSERT INTO Vehicle
                         (Vehicle, Model, Sub_Model, Year, Power, Top_Speed, Acceleration)
VALUES        ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox8.Text + "','" + textBox6.Text + "')", con);
            cmd.ExecuteNonQuery();

            con.Close();
            Display();
        }
        void Display()
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Vehicle", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["Vehicle"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Model"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["Sub_Model"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["Year"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["Power"].ToString();
                dataGridView1.Rows[n].Cells[5].Value = item["Top_Speed"].ToString();
                dataGridView1.Rows[n].Cells[6].Value = item["Acceleration"].ToString();

            }


        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox8.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"DELETE FROM Vehicle
WHERE        (Sub_Model = '" + textBox3.Text+ "')", con);
            cmd.ExecuteNonQuery();

            con.Close();
            Display();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"UPDATE       Vehicle
SET                Vehicle ='"+textBox1.Text+"', Model ='"+textBox2.Text+"', Sub_Model ='"+textBox3.Text+"', Year ='"+textBox4.Text+"', Power ='"+textBox5.Text+"', Top_Speed ='"+textBox8.Text+"', Acceleration ='"+textBox6.Text+"' WHERE        (Sub_Model = '"+textBox3.Text+"')", con);
            cmd.ExecuteNonQuery();

            con.Close();
            Display();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Vehicle WHERE (Vehicle like '%" + textBox7.Text + "%') or (Model like '%" + textBox7.Text + "%') or (Sub_Model like '%" + textBox7.Text + "%') or (Year like '%" + textBox7.Text + "%') or (Power like '%" + textBox7.Text + "%') or (Top_Speed like '%" + textBox7.Text + "%') or (Acceleration like '%" + textBox7.Text + "%') ", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["Vehicle"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Model"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["Sub_Model"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["Year"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["Power"].ToString();
                dataGridView1.Rows[n].Cells[5].Value = item["Top_Speed"].ToString();
                dataGridView1.Rows[n].Cells[6].Value = item["Acceleration"].ToString();

            }
        }
    }
}