﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Tanmay\Documents\New_registration.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT count(*) From New_Registration where E_mail='" + textBox1.Text + "' and New_Password='"+textBox2.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
            this.Hide();
            Vehicles_Showroom vh = new Vehicles_Showroom();
            vh.Show();
            }
            else
            {
                MessageBox.Show("Please enter correct password and e_mail id");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                this.Hide();
                New_registration nr = new New_registration();
                nr.Show();
           
        }


      

    }
}
